/* Simplified Chinese initialisation for the jQuery UI multiselect plugin. */
/* Written by Ben (ben@zfben.com). */

(function ( $ ) {

$.extend($.ech.multiselect.prototype.options, {
	checkAllText: '全选',
	uncheckAllText: '清空',
	noneSelectedText: '请选择',
	selectedText: '# 项已选择' ,//显示文字
	minWidth:158,//默认宽度255
	selectedList:2

});

})( jQuery );


/**
*常用方法 例子
*
*
*/